module.exports = {
  BOT_TOKEN: "Bot token add db lu",
  DEVELOPER_ID: 8066548394,

  GITHUB_TOKEN: "Halo", //isi personal token
  GITHUB_OWNER: "nama github", //isi nama github lu
  GITHUB_REPO: "Hydra-database", //nama repo lu
  GITHUB_FILE_PATH: "token.json", //tempat lu naro token
  GITHUB_BRANCH: "main" // yg ini ga usah di gausah di ganti
}