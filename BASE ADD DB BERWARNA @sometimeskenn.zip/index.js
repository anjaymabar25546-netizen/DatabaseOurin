const TelegramBot = require("node-telegram-bot-api")
const axios = require("axios")
const fs = require("fs")
const path = require("path")
const config = require("./config")

const bot = new TelegramBot(config.BOT_TOKEN, { polling: true })
const sellerPath = path.join(__dirname, "sellers.json")

// ================= SELLER =================
function loadSeller() {
  if (!fs.existsSync(sellerPath)) {
    fs.writeFileSync(sellerPath, JSON.stringify([], null, 2))
  }
  return JSON.parse(fs.readFileSync(sellerPath))
}

function saveSeller(data) {
  fs.writeFileSync(sellerPath, JSON.stringify(data, null, 2))
}

function isSeller(id) {
  return loadSeller().includes(id)
}

// ================= GITHUB =================
async function getGitHubFile() {
  const url = `https://api.github.com/repos/${config.GITHUB_OWNER}/${config.GITHUB_REPO}/contents/${config.GITHUB_FILE_PATH}`

  const res = await axios.get(url, {
    headers: {
      Authorization: `Bearer ${config.GITHUB_TOKEN}`,
      Accept: "application/vnd.github+json"
    }
  })

  const content = Buffer.from(res.data.content, "base64").toString()
  return {
    json: JSON.parse(content),
    sha: res.data.sha
  }
}

async function updateGitHubFile(newData, sha) {
  const url = `https://api.github.com/repos/${config.GITHUB_OWNER}/${config.GITHUB_REPO}/contents/${config.GITHUB_FILE_PATH}`

  const encoded = Buffer.from(
    JSON.stringify(newData, null, 2)
  ).toString("base64")

  await axios.put(
    url,
    {
      message: "Update token via Telegram Bot",
      content: encoded,
      sha: sha,
      branch: config.GITHUB_BRANCH
    },
    {
      headers: {
        Authorization: `Bearer ${config.GITHUB_TOKEN}`,
        Accept: "application/vnd.github+json"
      }
    }
  )
}

// ================= MENU UTAMA =================
bot.onText(/\/start/, (msg) => {
  bot.sendPhoto(msg.chat.id, "https://i.ibb.co/JwYCcrYk/x.jpg", {
    caption:
`DATABASE UMA - INFINITY

Silakan pilih menu di bawah.`,
    parse_mode: "Markdown",
    reply_markup: {
      inline_keyboard: [
        [
          { text: "📂 Token Menu", callback_data: "token_menu", style: "Success" },
          { text: "👑 Developer", callback_data: "dev_menu", style: "Danger" }
        ]
      ]
    }
  })
})

// ================= BUTTON HANDLER =================
bot.on("callback_query", async (query) => {
  const chatId = query.message.chat.id
  const messageId = query.message.message_id
  const userId = query.from.id
  const data = query.data

  if (data === "token_menu") {
    if (!isSeller(userId)) {
      return bot.answerCallbackQuery(query.id, {
        text: "❌ Menu khusus seller!",
        show_alert: true
      })
    }

    bot.editMessageCaption(
`📂 *TOKEN MENU*

Gunakan command:

/addtoken TOKEN
/listtoken`,
      {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "Markdown",
        reply_markup: {
          inline_keyboard: [
            [{ text: "⬅️ Back", callback_data: "back_main", style: "Primary" }]
          ]
        }
      }
    )
  }

  if (data === "dev_menu") {
    bot.editMessageCaption(
`👑 *DEVELOPER MENU*

/addseller ID`,
      {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "Markdown",
        reply_markup: {
          inline_keyboard: [
            [{ text: "⬅️ Back", callback_data: "back_main", style: "Danger" }]
          ]
        }
      }
    )
  }

  if (data === "back_main") {
    bot.editMessageCaption(
`𝐀𝐃𝐃 𝐓𝐎𝐊𝐄𝐍 𝐁𝐎𝐓𝐙𝐒𝐗

Silakan pilih menu di bawah.`,
      {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "Markdown",
        reply_markup: {
          inline_keyboard: [
            [
              { text: "📂 Token Menu", callback_data: "token_menu", style: "Success" },
              { text: "👑 Developer", callback_data: "dev_menu", style: "Danger" }
            ]
          ]
        }
      }
    )
  }

  bot.answerCallbackQuery(query.id)
})

// ================= ADD TOKEN =================
bot.onText(/\/addtoken (.+)/, async (msg, match) => {
  const chatId = msg.chat.id
  const userId = msg.from.id
  const token = match[1].trim()

  if (!isSeller(userId)) {
    return bot.sendMessage(chatId, "❌ Hanya seller!")
  }

  try {
    const { json, sha } = await getGitHubFile()

    if (!json.tokens) json.tokens = []

    if (json.tokens.includes(token)) {
      return bot.sendMessage(chatId, "❌ Token sudah ada!")
    }

    json.tokens.push(token)

    await updateGitHubFile(json, sha)

    bot.sendMessage(chatId, "✅ Token berhasil ditambahkan ke GitHub!")
  } catch (err) {
    console.log(err.response?.data || err.message)
    bot.sendMessage(chatId, "❌ Gagal update GitHub!")
  }
})

// ================= LIST TOKEN =================
bot.onText(/\/listtoken/, async (msg) => {
  const chatId = msg.chat.id
  const userId = msg.from.id

  if (!isSeller(userId)) {
    return bot.sendMessage(chatId, "❌ Hanya seller!")
  }

  try {
    const { json } = await getGitHubFile()

    if (!json.tokens || json.tokens.length === 0) {
      return bot.sendMessage(chatId, "Database kosong.")
    }

    bot.sendMessage(chatId, "📂 Token List:\n\n" + json.tokens.join("\n"))
  } catch (err) {
    bot.sendMessage(chatId, "❌ Gagal ambil data!")
  }
})

// ================= ADD SELLER =================
bot.onText(/\/addseller (.+)/, (msg, match) => {
  const chatId = msg.chat.id
  const userId = msg.from.id
  const newSeller = parseInt(match[1])

  if (userId !== config.DEVELOPER_ID) {
    return bot.sendMessage(chatId, "❌ Hanya developer!")
  }

  let sellers = loadSeller()

  if (sellers.includes(newSeller)) {
    return bot.sendMessage(chatId, "Seller sudah ada.")
  }

  sellers.push(newSeller)
  saveSeller(sellers)

  bot.sendMessage(chatId, "✅ Seller berhasil ditambahkan!")
})

console.log("🔥 Bot aktif dengan menu foto!")